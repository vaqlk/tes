# Rooftop Snipers
The chaotic two-push-button Rooftop Snipers unblocked game created by Michael Eykhler will turn players into snipers on a roof of the high building. It is necessary to get to the rival and to dump him from a roof, but to make it quite not easy. Fairly sways snipers that turns aiming into incredibly difficult task. Try to turn aside from bullets, the bullet or the axe can strongly push away the character and throw off down!

One can play Rooftop Snipers unblocked against the computer, but it is better to find the friend and to organize a duel. The player who won several rounds in a row will win.

![preview](https://user-images.githubusercontent.com/58097612/140696952-3b498771-d633-4677-b3f4-74981034d26e.png)

## Play
Click the link below to play!

[https://3kh0.github.io/rooftop-snipers/](https://3kh0.github.io/rooftop-snipers/)
